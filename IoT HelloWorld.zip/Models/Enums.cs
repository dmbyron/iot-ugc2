﻿namespace StudioUgc.Models
{
	public enum UgcType
	{
		Image,
		Video,
	}
}
