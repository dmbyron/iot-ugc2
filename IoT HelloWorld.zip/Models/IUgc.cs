﻿namespace StudioUgc.Models
{
	public interface IUgc
	{
		string Source { get; }
		UgcType Type { get; }
	}
}
